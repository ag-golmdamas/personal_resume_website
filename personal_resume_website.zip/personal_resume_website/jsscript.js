function validate_message {
	alert("Are you sure?");
}
